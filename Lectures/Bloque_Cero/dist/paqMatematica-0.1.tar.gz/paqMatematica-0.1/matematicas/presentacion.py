# matematicas/presentacion.py

def hola():
    print('Hola mundo')
    
def adios():
    print('Adios mundo')