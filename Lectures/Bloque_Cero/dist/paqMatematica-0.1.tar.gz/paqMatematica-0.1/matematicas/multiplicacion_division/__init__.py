# matematicas/multiplicacion_division/__init__.py
from .divisionF import division
from .multiplicacionF import multiplicacion

__all__ = [
    # divisionF
    'division',
    # multiplicacionF
    'multiplicacion'
]