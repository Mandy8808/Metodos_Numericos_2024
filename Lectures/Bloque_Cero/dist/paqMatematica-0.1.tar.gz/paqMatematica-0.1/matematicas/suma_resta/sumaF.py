# matematicas/suma_resta/suma.py

def suma(*args):
    """
    Acá va la info
    """
    return sum([i for i in args])