# matematicas/suma_resta/__init__.py

from .sumaF import *
from .restaF import *

# especificamos que modulos se importan con: from <module> import *
__all__ = ['suma', 'resta']